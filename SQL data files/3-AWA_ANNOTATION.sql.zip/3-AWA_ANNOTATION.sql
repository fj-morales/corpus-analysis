-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: AWA
-- ------------------------------------------------------
-- Server version	5.7.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `ANNOTATION`
--

INSERT INTO ANNOTATION VALUES (1,'1_claiming_centrality',1),(2,'2_making_topic_generalizations',1),(3,'5_indicating_a_gap',1),(4,'9_announcing_present_research',1),(5,'10_announcing_principal_findings',1),(6,'11_evaluation_of_research',1),(7,'Important',2),(8,'Summary',2),(9,'Important&Summary',2),(10,'Background',2),(11,'Contrast',2),(12,'Emphasis',2),(13,'Novelty',2),(14,'Position',2),(15,'Question',2),(16,'Surprise',2),(17,'Trend',2),(18,'AWA3_Background',3),(19,'AWA3_Contrast',3),(20,'AWA3_Emphasis',3),(21,'AWA3_Novelty',3),(22,'AWA3_Position',3),(23,'AWA3_Question',3),(24,'AWA3_Surprise',3),(25,'AWA3_Trend',3),(26,'AWA3_Important',3),(27,'AWA3_Summary',3),(28,'AWA3_Important&Summary',3),(29,'disc_concl_m1_reestablishing_territory',4),(30,'disc_concl_m2_framing_principal_findings',4),(31,'disc_concl_m3_reshaping_the_territory',4),(32,'disc_concl_m4_establishing_additional_territory',4),(34,'introductions_m1_establishing_territory',4),(35,'introductions_m2_identifying_niche',4),(36,'introductions_m3_addressing_niche',4),(37,'AWA3_Tempstat',3),(38,'AWA3_Anyauthor',3);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
